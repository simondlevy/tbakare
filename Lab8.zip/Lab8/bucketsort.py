import random
from sorts import quickSort
import time
import csv

def bucketSort(lyst):
    #create new list to place sorted numbers
    sorted_lyst = list()

    # Create a bucket to accommodate the counts for the index
    #return an empty list if the given list is empty
    try:
        bucket = [0] * (max(lyst) + 1)
    except ValueError:
        return []

    #iterate through list and update bucket value matching index
    for number in lyst:
        bucket[number] += 1

    #iterate through bucket and add the index for the amount of counts it appears
    for index, amount in enumerate(bucket):
        sorted_lyst += [index] * amount

    return sorted_lyst

def randints(n):

    random_lyst = random.choices(range(0,n), k=n)

    return random_lyst

def test(q, lyst):

    start_time = time.perf_counter()
    q(lyst)
    end_time = time.perf_counter()
    elapsed_time = end_time - start_time

    return elapsed_time

if __name__ == '__main__':

    print("Testing bucketsort on lists I created")

    o = [1,2,3,4,5,6,7,8,9,10]

    print("Original list: ", o)
    print("Sorted list: ", bucketSort(o))

    print()

    a = [3,8,1,5,7,8,3,0]

    print("Original list: ", a)
    print("Sorted list: ", bucketSort(a))

    print()

    b = [2,20,1,4,5,5,20,21,6,10,30,20,19,29]

    print("Original list: ", b)
    print("Sorted list: ", bucketSort(b))

    print()
    print("Testing bucketsort on randomly generated lists")

    c = randints(10)

    print("Random list: ", c)
    print("Sorted list: ", bucketSort(c))

    print()

    d = randints(20)

    print("Random list: ", d)
    print("Sorted list: ", bucketSort(d))

    print()

    print("SPEED CONTESTS")

    A = randints(1000)
    copyA = A
    BuckA = test(bucketSort, A)
    QuickA = test(quickSort, copyA)
    print("Bucket Sort on 1,000 items took", BuckA, "seconds")
    print("Quick Sort on 1,000 items took", QuickA, "seconds")
    
    print()
    B = randints(10000)
    copyB = B
    BuckB = test(bucketSort, B)
    QuickB = test(quickSort, copyB)
    print("Bucket Sort on 10,000 items took", BuckB, "seconds")
    print("Quick Sort on 10,000 items took", QuickA, "seconds")
    
    print()
    C = randints(100000)
    copyC = C
    BuckC = test(bucketSort, C)
    QuickC = test(quickSort, copyC)
    print("Bucket Sort on 100,000 items took", BuckC, "seconds")
    print("Quick Sort on 100,000 items took", QuickC, "seconds")
    
    print()
    D = randints(1000000)
    copyD = D
    BuckD = test(bucketSort, D)
    QuickD = test(quickSort, copyD)
    print("Bucket Sort on 10,000,000 items took", BuckD, "seconds")
    print("Quick Sort on 10,000,000 items took", QuickD, "seconds")
    
    print()
    E = randints(10000000)
    copyE = E
    BuckE = test(bucketSort, E)
    QuickE = test(quickSort, copyE)
    print("Bucket Sort on 100,000000 items took", BuckE, "seconds")
    print("Quick Sort on 100,000,000 items took", QuickE, "seconds")

    data = [
    ["List Length", "BucketSort", "QuickSort"],
    ["1000", BuckA , QuickA],
    ["10000", BuckB, QuickB],
    ["100000", BuckC, QuickC],
    ["1000000", BuckD, QuickD],
    ["10000000", BuckE, QuickE]]

    with open("comparisons.csv", mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerows(data)
